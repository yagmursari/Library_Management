﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management3
{

    public abstract class ListViewBaseDecorator : ListViewBase
    {
        public ListViewBase listView;
    }
}
